#pragma once
#include "USTC_CG.h"
#include "pxr/base/gf/vec3f.h"
USTC_CG_NAMESPACE_OPEN_SCOPE
using Color = pxr::GfVec3f;
USTC_CG_NAMESPACE_CLOSE_SCOPE